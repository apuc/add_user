<h1>Информация о пользователе</h1>
<a class = "btn" href="/wp-admin/admin.php?page=add_user&action=del&id={ID}">Удалить</a>
<a class = "btn" href="/wp-admin/admin.php?page=add_user&action=edit&ref=see&id={ID}">Редактировать</a>


<!--<p><strong>Имя</strong> {first_name}</p>
<p><strong>Логин</strong> {user_login}</p>
<p><strong>Email</strong> {user_email}</p>

<p><strong>Название компании</strong> {name_komp}</p>
<p><strong>Номер телефона</strong> {telephone}</p>
<p><strong>ИНН</strong> {inn}</p>
<p><strong>Лицевой счет</strong> {lic}</p>
<p><strong>Номер договора</strong> {nomdogovor}</p>
<p><strong>Дата договора</strong> {date_dog}</p>
<p><strong>Адрес</strong> {adres}</p>-->
{fields}
