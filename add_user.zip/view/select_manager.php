<p>Выберите роль
    <select name="role" id="role">
        <option value="0">Выберите роль</option>
        <option value="user">Пользователь</option>
    </select>
</p>