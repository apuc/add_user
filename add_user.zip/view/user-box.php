<div class="user">
    <table width="100%">
        <tr>
            <td width="20%">
                <a href="/wp-admin/admin.php?page=add_user&action=del&id={ID}"><img src="{path}images/del.png" alt=""/></a>
                <a href="/wp-admin/admin.php?page=add_user&action=edit&id={ID}"><img src="{path}images/edit.png" alt=""/></a>
                <a href = "/wp-admin/admin.php?page=add_user&action=see&id={ID}""><img src="{path}images/see.png" alt=""/></a>
            </td>
            <td width="20%">{ID}</td>
            <td width="20%">{user_login}</td>
            <td width="20%">{user_email}</td>
        </tr>
    </table>
</div>