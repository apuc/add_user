<h1>Результаты поиска</h1>

<a href = "/wp-admin/admin.php?page=add_user">Вернуться к списку пользователе</a>

<form  action="/wp-admin/admin.php?page=add_user" method="POST">
    <input type="text" name = "search"/>
    <input type="submit" value="Поиск" />
</form>