<div><a href = "/wp-admin/admin.php?page=add_user&action=import">Статистика импорта</a></div>
