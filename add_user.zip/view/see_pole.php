<h1>Список полей</h1>

<table width="100%">
    <tr>
        <th width="20%">
        </th>
        <th width="20%">
            ID
        </th>
        <th width="20%">
            Поле латиница
        </th>
        <th width="20%">
            Поле на русском
        </th>

    </tr>
</table>