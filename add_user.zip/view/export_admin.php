<div><a href = "/wp-admin/admin.php?page=add_user&action=export">Экспортировать данные Exel</a></div>
