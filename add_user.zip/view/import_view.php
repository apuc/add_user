<table style = "width:100%;">
    <tr>
        <th>
            Дата
        </th>
        <th>
            Количество
        </th>
    </tr>
    {stat}
</table>
