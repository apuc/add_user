<tr>
    <td>{date}</td>
    <td>{kol}</td>
</tr>