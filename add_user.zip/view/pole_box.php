<div class="pole">
    <table width="100%">
        <tr>
            <td width="20%">
                <a href="/wp-admin/admin.php?page=add_user&action=del_pole&id={id}"><img src="{path}images/del.png" alt=""/></a>
            </td>
            <td width="20%">{id}</td>
            <td width="20%">{key}</td>
            <td width="20%">{label}</td>
        </tr>
    </table>
</div>

