<h1>Пользователи</h1>

{export}
{import}

<a class = "btn add" href="/wp-admin/admin.php?page=add_user&action=add_form">Добавить пользователя</a>
<a class = "btn add" href="/wp-admin/admin.php?page=add_user&action=add_pole">Добавить поле</a>
<a class = "btn" href="/wp-admin/admin.php?page=add_user&action=see_pole">Посмотреть поля</a>

<form  action="/wp-admin/admin.php?page=add_user" method="POST">
    <input type="text" name = "search"/>
    <input type="submit" value="Поиск" />
</form>
