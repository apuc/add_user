<th width="20%">
    {label}
</th>