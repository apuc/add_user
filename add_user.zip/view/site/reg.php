<form action="" method="post">
    <p>Ваш логин:<br>
        <input name="login" type="text" size="15" maxlength="15">
    </p>
    <p>
        Ваш пароль:<br>
        <input name="password" type="password" size="15" maxlength="15">
    </p>
    <p>
        <input type="submit" name="submit" value="Войти">
    </p>
</form>