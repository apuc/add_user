<a href="{url}"> Перейти в админ панель</a>

{fields}