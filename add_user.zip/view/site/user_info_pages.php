<p><strong>{label}</strong> {value}</p>
